package com.example.hospital.controller;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;

@Controller
public class LoginController {

    @GetMapping({"/", "/escolher-login"})
    public String escolher() {
        return "index"; // página inicial de escolha
    }

    @GetMapping("/login")
    public String login(@RequestParam(value="role", required=false) String role, Model model) {
        model.addAttribute("role", role);
        return "login"; // templates/login.html
    }
}
