package com.example.hospital;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class HospitalVidaNovaApplicationTests {

    @Test
    void contextLoads() {
        // Teste mínimo para validar se a aplicação sobe corretamente
    }

}
